package org.mtito.springcloud.msvc.cursos.msvccursos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcCursosApplicationTests {

	@Test
	void contextLoads() {
	}

}
